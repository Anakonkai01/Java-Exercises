package exercise3;

public interface Vegetable {
    String getInfo();
}
